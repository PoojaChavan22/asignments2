package Lab2;

public class example2a {
    
	String fname,lname,gender;
    int age;
    double weight;
    

	public example2a(String fname, String lname, String gender, int age,double weight) {
		this.fname = fname;
		this.lname = lname;
		this.gender = gender;
		this.age = age;
		this.weight = weight;
	}


	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public void display()
	{
		System.out.println("First Name: "+fname);
		System.out.println("Last Name: "+lname);
		System.out.println("Gender: "+gender);
		System.out.println("Age: "+age);
		System.out.println("Weight: "+weight);
	}


	public static void main(String[] args) {
        example2a e = new example2a("Divya", "Bharathi", "F", 20 , 85.5);
        e.display();
	}

}
