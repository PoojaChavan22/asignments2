package Lab3;
import java.time.LocalDate; 
import java.time.Period;
import java.util.Scanner;
public class DateTime {

		public static Period dateDiff(){
				Scanner sc = new Scanner(System.in);
				LocalDate start = LocalDate.of(sc.nextInt(),sc.nextInt(),sc.nextInt());
				LocalDate end = LocalDate.now();
				Period period = start.until(end);
				sc.close();
				return period;
			}
		 

public static void main(String[] args) {	
	System.out.println("Enter Dates in format (yyyy mm dd)  ");
	Period period = dateDiff();
	System.out.println("Days:"+ Math.abs(period.getDays()));
	System.out.println("Months:"+Math.abs(period.getMonths()));
	System.out.println("Years:"+ Math.abs(period.getYears()));
	
} 
		

}
