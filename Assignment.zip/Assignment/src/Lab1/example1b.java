package lab1;

import java.util.*;
import java.util.Scanner;

	public class example1b {
		
public static void main(String[] args) {
	int salary;
    String designation;
    
    Scanner  sc = new Scanner(System.in);
    
    System.out.println("Enter the designation of the Employee:"
    		+"As System Associate"+"/Programmer"+"/Manager"+"/Clerk: " );
    designation = sc.nextLine();
    System.out.println("Enter the salary of Employee:");
    salary = sc.nextInt();
  		   sc.nextLine();
  		   
   if(salary > 5000 && salary < 20000 && designation.equals("System Associate"))
   {
  	 System.out.println("Scheme C");
   }
   
   else if(salary >= 20000 && salary < 40000 && designation.equals("Programmer"))
   {
  	 System.out.println("Scheme B");
   }
   
   else if(salary >= 40000 && designation.equals("Manager"))
   {
  	 System.out.println("Scheme A");
   }
   
   else if(salary < 5000 && designation.equals("Clerk"))
   {
  	 System.out.println("No Schema");
   }
   
   else
   {
  	 System.out.println("Please put correct Input");
   }
}

}
