package Lab2d;

import java.util.Scanner;

public class Person {
	String firstName,lastName,gender;
	long number;
	int age;
	
	Scanner sc = new Scanner(System.in);
	
	public Person(){}
	
public Person(String firstName, String lastName, String gender, int age) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.age = age;
	}

 
public String getFirstName() {
	return firstName;
}


public void setFirstName(String firstName) {
	this.firstName = firstName;
}


public String getLastName() {
	return lastName;
}


public void setLastName(String lastName) {
	this.lastName = lastName;
}


public String getGender() {
	return gender;
}


public void setGender(String gender) {
	this.gender = gender;
}


public int getAge() {
	return age;
}


public void setAge(int age) {
	this.age = age;
}


public void getnumber()
{
	System.out.println("Enter number: ");
	number = sc.nextLong();
	         sc.nextLine();
}

public void display()
{
	System.out.println("Name: "+firstName);
	System.out.println("Surname: "+lastName);
	System.out.println("Gender: "+gender);
	System.out.println("Age: "+age);
	System.out.println("Phone number: "+number);
}

}
