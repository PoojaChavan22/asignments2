package Lab3;

import java.util.Scanner;

public class StringFunction {
public static void main(String[] args) {
	int choice;
	String instr;
	Scanner sc= new Scanner(System.in);
	
	System.out.println("Enter a String");
	instr= sc.nextLine();
	
	System.out.println("Enter choince of operation");
	System.out.println("1. Add the String to itself");
	System.out.println("2. Replace odd positions with #");
	System.out.println("3. Remove duplicate characters in the String");
	System.out.println("4. Change odd characters to upper case");
	System.out.println("0. Exit");
	choice = sc.nextInt();
	
	switch(choice)
	{
		case 0: break;
		
		case 1: addstr(instr);
				break;
		
		case 2: replace(instr);
				break;
			
		case 3: remove(instr);
				break;
				
		case 4: change(instr);
				break;
				
		default: break;
		
	}
	sc.close();
}

public static void addstr (String instr)
{
	String newstr= instr;
	newstr = instr.concat(instr);
	System.out.println("Output is "+newstr);
}

public static void replace (String instr)
{
	for(int i=0; i<instr.length();i++)
	{
		if ((i%2)==1)
		{
			 instr = instr.substring(0,i-1) + "#" + instr.substring(i, instr.length());
		}
	}
	System.out.println("Output is "+instr);
}

public static void remove (String instr)
{
	String newstr="";
	int len=instr.length();
	for(int i=0; i<len;i++)
	{
		if(!newstr.contains(String.valueOf(instr.charAt(i))))
		{
			newstr += String.valueOf(instr.charAt(i));
		}
	}
	System.out.println("Output is "+newstr);
	
}


public static void change(String instr)
{
	for(int i=0; i<instr.length();i++)
	{
		if((i%2)==1)
		{
			String a1 = instr.substring(i,i+1);
			instr = instr.substring(0,i)+a1.toUpperCase()+instr.substring(i+1,instr.length());
		}
	}
	System.out.println("Output is "+instr);
}
}
