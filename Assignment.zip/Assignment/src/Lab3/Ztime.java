package Lab3;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Ztime {
	
	public static void main(String[] args) {
	      System.out.println("Enter the Zone : ");
	      Scanner sc = new Scanner(System.in);
	      String zoneName;
          zoneName = sc.nextLine();	 
          final ZoneId zoneId = ZoneId.of(zoneName);
          final ZonedDateTime zonedDateTime = ZonedDateTime.ofInstant(Instant.now(),zoneId);
          System.out.println(zonedDateTime.format(DateTimeFormatter.ISO_ZONED_DATE_TIME));
          sc.close();
	}
}
