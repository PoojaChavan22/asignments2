package lab1;

import java.util.Scanner;


public class example1a {

	public static void main(String[] args) {
		String name,typeOfAccount;
		int accountNumber;
		String str = "saving";
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Account Number: ");
		accountNumber=sc.nextInt();
				      sc.nextLine();
		
	    System.out.println("Enter the Account Holder Name: ");
		name=sc.nextLine();
		
		System.out.println("Enter the type of Account: ");
		typeOfAccount=sc.nextLine();
		
		System.out.println("Account Number"+" "+"Name"+" "+"Type Of Account");             
		System.out.println(accountNumber+" "+name+" "+typeOfAccount);
	}

}
