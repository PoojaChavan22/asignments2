package Lab3;

	import java.time.YearMonth;
	import java.time.format.DateTimeFormatter;
	import java.time.format.DateTimeParseException;
	import java.util.Scanner;
	public class CalcExpiryDate 
	{

		public static void main(String[] args) 
		{
			Scanner sc = new Scanner(System.in);
			YearMonth purchasedate;
			System.out.println("Enter purchase date in format MM YYYY");
			String input = sc.nextLine();
			try 
			{
			    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM yyyy");
			    purchasedate = YearMonth.parse(input, formatter);
		
			}
			catch (DateTimeParseException exc)
			{
			    System.out.printf("%s is not parsable!%n", input);
			    throw exc;
			}
			
			
			System.out.println("Enter warranty period in format MM YYYY");
			long mon=sc.nextLong();
			long yrs=sc.nextLong();
			
			System.out.println("The product will expire on "+ purchasedate.plusMonths(mon).plusYears(yrs));
			sc.close();
		}
		

}


