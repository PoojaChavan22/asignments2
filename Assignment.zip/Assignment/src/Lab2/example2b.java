package Lab2;

import java.util.Scanner;

public class example2b {
    long number;
    
    Scanner sc = new Scanner(System.in);
    
    public example2b(){
        
    }
    
    public void getnumber(){
       System.out.println("Enter number: ");
       number = sc.nextInt();
                sc.nextLine();
                if(number > 0)
                {
                    System.out.println(number+" is positive");
                }
                else
                {
                    System.out.println(number+" is negative");
                }
    }

    public static void main(String[] args) {
        example2b a = new example2b();
        a.getnumber();
    }

}