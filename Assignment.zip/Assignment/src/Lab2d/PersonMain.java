package Lab2d;


public class PersonMain {
 public static void main(String[] args) {
	 Person e = new Person("Pooja", "Chavan", "F", 22);
		e.getnumber();
		e.display();
		
		System.out.println("***************************");
		
		Person e1 = new Person();
		e1.setFirstName("Ujwala");
		e1.setLastName("Chavan");
		e1.setGender("F");
		e1.setAge(50);
		e1.getnumber();
		e1.display();
}
}
