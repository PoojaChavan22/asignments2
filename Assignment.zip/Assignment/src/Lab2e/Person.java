package Lab2e;

	import java.util.Scanner;
	
	public class Person {
	String firstName;
	String lastName;
	long phoneNumber;
	Gender gender;
	 	 
	Scanner sc = new Scanner(System.in);
	 
	public Person() {
	 
	}

	public Person(String firstName, String lastName, Gender gender) {
	this.firstName = firstName;
	this.lastName = lastName;
	this.gender=gender;
	 
	}

	public String getFirstName() {
	return firstName;
	}

	public void setFirstName(String firstName) {
	this.firstName = firstName;
	}

	public String getLastName() {
	return lastName;
	}

	public void setLastName(String lastName) {
	this.lastName = lastName;
	}
	 
	public Gender getGender() {
	return gender;
	}



	public void setGender(Gender gender) {
	this.gender = gender;
	}

	public void acceptphnNo()
	{
	System.out.println("Enter Phone Number: ");
	phoneNumber = sc.nextLong();
	sc.nextLine();
	 
	}
	 
	 

	public void display()
	    {
	    System.out.println("First Name: "+firstName);
	    System.out.println("Last Name: "+lastName);
	    System.out.println("Gender: "+gender);
	    System.out.println("Phone Number: "+phoneNumber);
	    }

}






