package Lab3;

	import java.util.Scanner;


	public class PositiveString 
	{

		public static void main(String[] args) 
		{
			String chkstr;
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter a string");
			chkstr= sc.nextLine();
			int chkstrlength= chkstr.length();
			boolean posstr = true;
			for(int i=0; i<chkstrlength;i++)
			{
				for(int j=i+1; j>i && j<chkstrlength;j++)
				{
					if(chkstr.charAt(i) > chkstr.charAt(j))
					{
						posstr = false;
					}
				}
			}
			
			if(posstr == true)
			{
				System.out.println("String is positive");
			}
			else
				System.out.println("String is negative");
			sc.close();

		}

	}


