package Lab2e;

public class PersonMain {
	
		public static void main(String[] args) {
		Person p1 = new Person("Prakash","Chavan",Gender.M);
		p1.acceptphnNo();
		p1.display();
		 
		System.out.println("******************************************");
		Person p2 = new Person();
		p2.setFirstName("Pooja");
		p2.setLastName("Chavan");
		p2.setGender(Gender.F);
		p2.acceptphnNo();
		p2.display();
				 
		}
}
