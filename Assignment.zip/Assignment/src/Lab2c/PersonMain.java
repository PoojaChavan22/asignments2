package Lab2c;


public class PersonMain {
 public static void main(String[] args) {
	Person p = new Person("Pooja", "Chavan", 'F');
	
	Person p2 = new Person();
	p2.setFirstName("Kushal");
	p2.setLastName("Patil");
	p2.setGender('M');
	
	
	p.display();
	
	System.out.println("************************");
	
	p2.display();
}
}
