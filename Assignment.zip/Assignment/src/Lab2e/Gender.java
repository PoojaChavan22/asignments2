package Lab2e;

public enum Gender {
    M,F
}
